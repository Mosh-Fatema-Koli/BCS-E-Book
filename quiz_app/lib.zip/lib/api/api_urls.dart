class ApiUrl{
  static const String baseUrl = "http://bcsebook.wcnltd.com/s"; //url
  static const String api = "api/"; //api endpoint
  static const String apiUrl = baseUrl + api; //api url
  static const String imageUrl = baseUrl; //imageUrl url
}