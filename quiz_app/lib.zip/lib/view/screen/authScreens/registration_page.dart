import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:quiz_app/global/app_assets.dart';
import 'package:quiz_app/global/styles/textstyle.dart';
import 'package:quiz_app/view/components/button_widget.dart';
import 'package:quiz_app/view/components/textbox_widget.dart';
import 'package:quiz_app/view/screen/authScreens/login_screen.dart';
import 'package:quiz_app/view/screen/profile_page.dart';


import '../../../controller/registration_controller.dart';

class RegistrationPage extends StatelessWidget {
  final _controller = Get.put(RegistrationController());

  RegistrationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            color: Colors.transparent,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
              const SizedBox(height: 50),
              Center(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(100),
                    boxShadow: [

                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 100,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: Image.asset(
                      AppAssets.splash,
                      width: 80.h,
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              TextboxWidget(
                title: 'Name'.tr,
                controller: _controller.nameController,
                hintText: 'Enter your Name.'.tr,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 10),
              TextboxWidget(
                title: 'Email'.tr,
                controller: _controller.mailController,
                hintText: 'Enter your email address.'.tr,
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 10),
              TextboxWidget(
                title: "Phone Number".tr,
                controller: _controller.phoneController,
                hintText: "Enter your phone Number".tr,
                keyboardType: TextInputType.phone,
                isPassword: false,
              ),
              const SizedBox(height: 10),
              TextboxWidget(
                title: "Password".tr,
                controller: _controller.passwordController,
                hintText: "Enter your password".tr,
                keyboardType: TextInputType.visiblePassword,
                isPassword: true,
              ),
              const SizedBox(height: 10),
              TextboxWidget(
                title: "Confirm Password".tr,
                controller: _controller.confirmPasswordController,
                hintText: "Enter your password".tr,
                keyboardType: TextInputType.visiblePassword,
                isPassword: true,
              ),
              const SizedBox(height: 30),
              button(buttonName: "Register", navigation: ProfileScreen()),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Already Have an account?'.tr,
                    style: CustomtextStyle.maintext2.copyWith(
                      fontSize: 15.sp,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  InkWell(
                    onTap: () {
                      Get.to(() => LoginPage());
                    },
                    child: Text(
                      'Sign in'.tr,
                      style: CustomtextStyle.maintext2.copyWith(fontSize: 16.sp, color: HexColor("#2E2E54"),fontWeight:FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
