class AppAssets {
  static const String splash = 'assets/images/app_logo.png';
}
