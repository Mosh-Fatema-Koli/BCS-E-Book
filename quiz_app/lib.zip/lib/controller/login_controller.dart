import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginController extends GetxController {
  final mailController = TextEditingController();
  final passwordController = TextEditingController();
}
