import 'package:flutter/material.dart';
import 'package:get/get.dart';

class RegistrationController extends GetxController{
  final nameController = TextEditingController();
  final mailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
}