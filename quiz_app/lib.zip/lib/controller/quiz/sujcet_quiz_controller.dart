import 'package:get/get.dart';
import 'package:quiz_app/model/quiz/quiz-subject.dart';


class QuizSubjectController extends GetxController{

  final quizSubjectList= [
    QuizSubject(
      name:"Bangla",
      onPressed: (){

      }
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    ),
    QuizSubject(
        name:"Bangla",
        onPressed: (){}
    )

  ];



}