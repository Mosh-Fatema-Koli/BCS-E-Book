import 'package:get/get.dart';
import 'package:quiz_app/model/learn/subject_page_model.dart';


class SubjcetController extends GetxController{

 final subjectList=[
    Subject(name:" BANGLA", ),
    Subject(name:" ENGLISH", ),
    Subject(name:" MATH", ),
    Subject(name:" LITERATURE", ),
    Subject(name:" INTERNATIONAL", ),
    Subject(name:" BANGLADESH", ),
    Subject(name:" GEOGRAPHY", ),
    Subject(name:" COMPUTER", ),
    Subject(name:" MENTALABILITY", ),
    Subject(name:" ETHICS", ),
    Subject(name:" CHAMISTRY", )
  ];





}