class Subject{
  String? name;

  Subject({required this.name,});
}
