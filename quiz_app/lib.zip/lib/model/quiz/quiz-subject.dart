
import 'dart:ui';

class QuizSubject{
  String? name;
  final VoidCallback onPressed;

  QuizSubject({required this.name,required this.onPressed});
}
